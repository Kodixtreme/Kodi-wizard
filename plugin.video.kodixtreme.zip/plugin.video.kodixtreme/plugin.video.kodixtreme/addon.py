# -*- coding: utf-8 -*-
'''
 *  Copyright (C) 2023
 *  See LICENSE.txt for more information.
'''

from resources.lib import plugin


plugin.run()